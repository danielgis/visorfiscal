define({
  "_themeLabel": "珠寶箱主題",
  "_layout_default": "預設版面配置",
  "_layout_layout1": "版面配置 1",
  "emptyDocablePanelTip": "在「Widget」頁籤中按一下「+」按鈕以新增 widget。 "
});