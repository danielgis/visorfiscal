define({
  "_themeLabel": "Tema Portagioie",
  "_layout_default": "Layout predefinito",
  "_layout_layout1": "Layout 1",
  "emptyDocablePanelTip": "Fare clic sul pulsante + nella scheda Widget per aggiungere un widget. "
});