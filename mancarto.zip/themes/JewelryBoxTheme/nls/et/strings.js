define({
  "_themeLabel": "Teema Jewelry Box",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_layout1": "Paigutus 1",
  "emptyDocablePanelTip": "Vidina lisamiseks klõpsake sakil Vidin nuppu +. "
});