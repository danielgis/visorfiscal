define({
  "_themeLabel": "Chủ đề Hộp Trang sức",
  "_layout_default": "Bố cục mặc định",
  "_layout_layout1": "Bố cục 1",
  "emptyDocablePanelTip": "Bấm vào nút + trong tab Tiện ích để thêm tiện ích. "
});