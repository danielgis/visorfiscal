define({
  "_themeLabel": "Thème Boîte à options",
  "_layout_default": "Mise en page par défaut",
  "_layout_layout1": "Mise en page 1",
  "emptyDocablePanelTip": "Cliquez sur le bouton + sous l’onglet Widget pour ajouter un widget. "
});