define({
  "_themeLabel": "Jewelry Box-thema",
  "_layout_default": "Standaardlay-out",
  "_layout_layout1": "Lay-out 1",
  "emptyDocablePanelTip": "Klik op de + knop in het tabblad Widget om een widget toe te voegen. "
});