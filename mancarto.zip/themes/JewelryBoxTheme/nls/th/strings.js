define({
  "_themeLabel": "ธืมกล่องจิวเวอรี่",
  "_layout_default": "เค้าโครงเริ่มต้น",
  "_layout_layout1": "โครงร่าง 1",
  "emptyDocablePanelTip": "คลิกที่ปุ่ม + บนแท็บเครื่องมือที่จะเพิ่มวิดเจ็ต "
});