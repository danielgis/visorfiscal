define({
  "_themeLabel": "Salokāma tēma",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_layout1": "1. izkārtojums"
});